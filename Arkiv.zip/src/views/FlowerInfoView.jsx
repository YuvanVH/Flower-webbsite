import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';

const FlowerInfoView = () => {
  // State för att lagra den valda blomman och id från URL:en
  const [flower, setFlower] = useState(null);
  const { id } = useParams(); // Använd useParams-hook för att hämta id från URL:en

  // useEffect-hook för att hämta data för den valda blomman baserat på id
  useEffect(() => {
    // Funktion för att hämtaa blomdata från JSON-filen
    const fetchFlower = async () => {
      try {
        const response = await fetch('flowers.json'); // Fetcha JSON-data från filen 'flowers.json'
        const data = await response.json(); // Konvertera svaret till JSON-format
        const selectedFlower = data.find(flower => flower.id === parseInt(id)); // Hitta den valda blomman baserat på id
        setFlower(selectedFlower); // Uppdatera state med den valda blomman
      } catch (error) {
        console.error('Error fetching flower:', error); // Logga felmeddelande om det uppstår ett fel vid hämtning av data
      }
    };

    fetchFlower(); // Kör funktionen för att hämta data när komponenten monteras

    // Funktion som körs när komponenten demonteras för att undvika "minnesläckor"
    return () => {
      // Inget att rensa upp här i detta fall
    };
  }, [id]); // Uppdatera effekten när id ändras i URL:en

  // Visa laddningsmeddelande om blomman inte har hämtats ännu
  if (!flower) {
    return <div>Loading...</div>;
  }

  return (
    <div>
      {/* Visa namnet på den valda blomman */}
      <h1>{flower.name}</h1>
      {/* Visa resten av blominfo här */}
    </div>
  );
};

export default FlowerInfoView;
