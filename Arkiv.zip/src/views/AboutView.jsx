// src/views/AboutView.jsx
import React, { useContext } from 'react';
import { AboutContext } from '../components/AboutContext'; // Korrigera sökvägen till AboutContext


// fungerar ej orkar inte nå VG krav
function AboutView() {
  // const { aboutUsContent } = useContext(AboutContext);

  // return (
  //   <>
  //     <h1>About Us</h1>
  //     <div>
  //       {/* Visa innehållet från kontexten */}
  //       <p>{aboutUsContent}</p>
  //     </div>
  //   </>
  // );
}

export default AboutView;
