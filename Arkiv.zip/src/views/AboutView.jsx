// src/views/AboutView.jsx

function AboutView() {
}

export default AboutView;
