//src/menuUtils.js
export const toggleMenu = (setIsMenuOpen) => {
  setIsMenuOpen((prevState) => !prevState);
};
